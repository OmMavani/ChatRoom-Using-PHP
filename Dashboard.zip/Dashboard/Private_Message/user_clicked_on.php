<?php

$clicked_on_username = $_COOKIE["default_clicked_on_username"];
echo "$clicked_on_username";

?>
